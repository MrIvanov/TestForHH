package com.example.testforhh;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends Activity {

	public final static String EXTRA_MESSAGE = "com.example.testforhh.MESSAGE";
	public final static int REPLY_MESSAGE = 1;
	public final static int DIALOG_DATE = 11;
	int myYear = 1990;
	int myMonth = 11;
	int myDay = 29;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

	/*	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			ActionBar actionBar = getActionBar();
			actionBar.hide();
		}*/

		// ������������� � ��������� ���������� ��������� ������
		OnFocusChangeListener editFocusChange = new View.OnFocusChangeListener() {

			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				// ���� � ������, ������� ��������� formatDate(������ ������ ����)
				if (hasFocus) {
					formatDate(v);

				}
			}
		};
		// ��������� ���������� ������ ��� ���� ����� ��
		EditText birthDate = (EditText) findViewById(R.id.edit_birthdate);
		birthDate.setOnFocusChangeListener(editFocusChange);
	}

	// ��������� ����������: ���� �� �������� �������� �����
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == REPLY_MESSAGE) {
			if (resultCode == RESULT_OK) {
				String answer = data
						.getStringExtra(DisplayMessageActivity.ANSWER);

				AlertDialog.Builder builder = new AlertDialog.Builder(
						MainActivity.this);
				builder.setMessage(answer);
						builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
	                   public void onClick(DialogInterface dialog, int id) {
	                       // FIRE ZE MISSILES!
	                   }
	               });
	              
				builder.setTitle("���! ������ �����!");
				AlertDialog dialog = builder.create();
				dialog.show();
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@SuppressWarnings("deprecation")
	public void formatDate(View view) {
		showDialog(DIALOG_DATE);
	}

	public void sendMessage(View view) {
		// start the second activity
		Intent sendIntent = new Intent(this, DisplayMessageActivity.class);

		// create vars for EditTexts
		EditText name = (EditText) findViewById(R.id.edit_name);
		EditText vacancy = (EditText) findViewById(R.id.edit_vacancy);
		EditText salary = (EditText) findViewById(R.id.edit_salary);
		EditText phoneNum = (EditText) findViewById(R.id.edit_phonenum);
		EditText email = (EditText) findViewById(R.id.edit_email);
		Spinner gender = (Spinner) findViewById(R.id.spinner1);

		// get the strings
		String message = "���: "+ name.getText().toString()
				+ "\n���� ��������: "+ ((EditText) findViewById(R.id.edit_birthdate)).getText().toString() 
				+ "\n���: " + gender.getSelectedItem().toString() + 
				"\n���������: " + vacancy.getText().toString() + 
				"\n��������: "				+ salary.getText().toString() + "���.";
		String contacts = "�������:" + phoneNum.getText().toString()
				+ "\nE-mail: " + email.getText().toString();
		// Assign intent message
		sendIntent.putExtra(MainActivity.EXTRA_MESSAGE, message);
		sendIntent.putExtra("contact", contacts);
		startActivityForResult(sendIntent, REPLY_MESSAGE);

		// Call intent
		// EditText phone = (EditText) findViewById(R.id.editText2);
		// String number = "tel:"+phone.getText().toString();
		// Uri phonenum = Uri.parse(number);
		// Intent callIntent = new Intent(Intent.ACTION_DIAL,phonenum);
		// startActivity(callIntent);

		// Email intent
		// Intent emailIntent = new Intent(Intent.ACTION_SEND);
		// emailIntent.setType(HTTP.PLAIN_TEXT_TYPE);
		// emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]
		// {"Acid-2005@mail.ru"});
		// emailIntent.putExtra(Intent.EXTRA_SUBJECT, "������ �� ������");
		// emailIntent.putExtra(Intent.EXTRA_TEXT, "������ ����!");
		// emailIntent.putExtra(Intent.EXTRA_STREAM,
		// Uri.parse("content://path/to/email/attachment"))
		// PackageManager packageManager = getPackageManager();
		// List<ResolveInfo> activities =
		// packageManager.queryIntentActivities(emailIntent, 0);
		// boolean isIntentSafe = activities.size() > 0;
		/*
		 * if (isIntentSafe) { startActivity(emailIntent); };
		 */
	}

	@Override
	@SuppressWarnings("deprecation")
	protected Dialog onCreateDialog(int id) {
		if (id == DIALOG_DATE) {
			DatePickerDialog tpd = new DatePickerDialog(this, myCallBack,
					myYear, myMonth, myDay);

			tpd.setTitle("�������� ���� ��������");
			return tpd;
		}
		return super.onCreateDialog(id);
	}

	OnDateSetListener myCallBack = new OnDateSetListener() {
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			myYear = year;
			myMonth = monthOfYear;
			myDay = dayOfMonth;
			((EditText) findViewById(R.id.edit_birthdate)).setText(myDay + "."
					+ myMonth + "." + myYear);
		}
	};

};
